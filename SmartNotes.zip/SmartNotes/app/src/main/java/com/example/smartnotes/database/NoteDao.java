package com.example.smartnotes.database;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;
import com.example.smartnotes.models.Note;
import java.util.List;

@Dao
public interface NoteDao {

    // Get all notes, ordered by most recently updated
    @Query("SELECT * FROM notes ORDER BY updatedAt DESC")
    List<Note> getAllNotes();

    // Insert a single note
    @Insert
    void insert(Note note);

    // Update an existing note
    @Update
    void update(Note note);

    // Delete a note
    @Delete
    void delete(Note note);

    // Get a specific note by its ID
    @Query("SELECT * FROM notes WHERE id = :id")
    Note getNoteById(int id);
}
